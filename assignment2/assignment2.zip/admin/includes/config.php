<?php

session_start();

header( 'Content-type: text/html; charset=utf-8' );
