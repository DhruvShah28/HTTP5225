  
    <footer class="container-fluid mt-4 text-bg-secondary p-3 text-center">
        <div>&copy; 2025 Toronto Attractions. All rights reserved.</div>
    </footer>

</body>
</html>